import React from 'react'

const Quizzes = () => {
    return (
        <div>Quizzes</div>
    )
}

export default Quizzes